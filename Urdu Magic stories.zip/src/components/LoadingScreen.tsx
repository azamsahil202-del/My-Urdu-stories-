import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, BookOpen, Wand2 } from 'lucide-react';

interface LoadingScreenProps {
  topicTitle?: string;
}

const LOADING_PHRASES = [
  "مکمل 15 صفحات کی داستان ترتیب دی جا رہی ہے...",
  "پریوں اور پرندوں کے دیس سے الفاظ اکٹھے ہو رہے ہیں...",
  "کہانی کے جادوئی کردار اور مناظر تیار ہو رہے ہیں...",
  "چند لمحوں میں آپ کی 15 صفحات کی کہانی حاضر ہے...",
];

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ topicTitle }) => {
  const [phraseIndex, setPhraseIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setPhraseIndex((prev) => (prev + 1) % LOADING_PHRASES.length);
    }, 2400);
    return () => clearInterval(timer);
  }, []);

  return (
    <div id="loading-screen" className="w-full max-w-lg mx-auto py-16 text-center space-y-6">
      {/* Animated Magic Icon */}
      <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-0 rounded-full border-2 border-dashed border-emerald-400/60"
        />
        <motion.div
          animate={{ scale: [1, 1.12, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-xl shadow-emerald-600/30"
        >
          <BookOpen className="w-10 h-10 text-amber-200" />
        </motion.div>
        <motion.div
          animate={{ y: [-4, 4, -4], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="absolute -top-1 -right-1 text-amber-500"
        >
          <Sparkles className="w-7 h-7" />
        </motion.div>
      </div>

      {/* Topic Tag */}
      {topicTitle && (
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100/80 text-amber-900 border border-amber-300 text-sm font-nastaliq">
          <Wand2 className="w-4 h-4 text-amber-700" />
          <span>موضوع: {topicTitle}</span>
        </div>
      )}

      {/* Main Waiting Heading */}
      <div className="space-y-2">
        <h3 className="text-2xl sm:text-3xl font-bold text-stone-900 font-nastaliq">
          کہانی لکھی جا رہی ہے ✨
        </h3>
        <motion.p
          key={phraseIndex}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.4 }}
          className="text-stone-600 font-nastaliq text-base sm:text-lg min-h-[2.5rem]"
        >
          {LOADING_PHRASES[phraseIndex]}
        </motion.p>
      </div>

      {/* Progress line */}
      <div className="w-48 h-1.5 bg-stone-200 rounded-full mx-auto overflow-hidden">
        <motion.div
          animate={{ x: [-200, 200] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          className="w-24 h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"
        />
      </div>
    </div>
  );
};
