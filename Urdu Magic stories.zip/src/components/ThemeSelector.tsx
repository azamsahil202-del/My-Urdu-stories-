import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Wand2, Compass, BookMarked } from 'lucide-react';
import {
  THEMES,
  StoryTheme,
  CUSTOM_STORY_QUESTION,
  START_MAGIC_BUTTON,
} from '../types.ts';

interface ThemeSelectorProps {
  onStartThemeStory: (theme: StoryTheme) => void;
  onStartCustomStory: (customPrompt: string) => void;
  isLoading: boolean;
}

const QUICK_IDEAS = [
  "بولنے والی جادوئی بلی 🐱",
  "پروں والا گھوڑا 🦄",
  "جادوئی قالین کا سفر 🧶",
  "چمکتے ہیروں کی غار 💎",
  "دوست بننے والا ڈریگن 🐉",
];

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({
  onStartThemeStory,
  onStartCustomStory,
  isLoading,
}) => {
  const [customInput, setCustomInput] = useState('');
  const [selectedThemeId, setSelectedThemeId] = useState<string | null>(null);

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim() || isLoading) return;
    onStartCustomStory(customInput.trim());
  };

  const handleSelectQuickIdea = (idea: string) => {
    // Strip trailing emoji for clean prompt
    const cleaned = idea.replace(/[\u{1F300}-\u{1F9FF}]/gu, '').trim();
    setCustomInput(cleaned);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8">
      {/* Introduction Card */}
      <div className="text-center space-y-3 bg-gradient-to-b from-white to-amber-50/70 p-6 sm:p-8 rounded-3xl border border-amber-200/70 shadow-sm">
        <h2 className="text-2xl sm:text-4xl font-bold text-stone-900 font-nastaliq leading-relaxed">
          اپنے پسندیدہ موضوع کا انتخاب کریں
        </h2>
        <p className="text-stone-600 max-w-xl mx-auto text-base sm:text-lg font-nastaliq">
          کسی بھی تھیم پر کلک کریں یا نیچے اپنا من پسند خیال لکھ کر جادوئی کہانی سنیں!
        </p>
      </div>

      {/* Preset 4 Themes Grid */}
      <div>
        <div className="flex items-center gap-2 mb-4 px-2">
          <Compass className="w-5 h-5 text-emerald-700" />
          <h3 className="text-lg font-bold text-stone-800 font-nastaliq">
            مشہور جادوئی تھیمز
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {THEMES.map((theme, index) => {
            const isSelected = selectedThemeId === theme.id;
            return (
              <motion.button
                key={theme.id}
                id={`theme-card-${theme.id}`}
                whileHover={{ scale: 1.015, y: -2 }}
                whileTap={{ scale: 0.985 }}
                onClick={() => {
                  setSelectedThemeId(theme.id);
                  onStartThemeStory(theme);
                }}
                disabled={isLoading}
                className={`relative text-right p-6 rounded-2xl border-2 transition-all shadow-xs cursor-pointer overflow-hidden ${
                  theme.accentBg || 'bg-white'
                } ${
                  theme.accentBorder || 'border-stone-200'
                } ${isSelected ? 'ring-3 ring-emerald-500 border-emerald-500' : ''}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-3xl sm:text-4xl" role="img" aria-hidden="true">
                        {theme.icon}
                      </span>
                      <h4 className="text-xl sm:text-2xl font-bold text-stone-900 font-nastaliq">
                        {theme.titleUrdu}
                      </h4>
                    </div>
                    {theme.desc && (
                      <p className="text-stone-600 text-sm sm:text-base font-nastaliq pr-1">
                        {theme.desc}
                      </p>
                    )}
                  </div>
                  <div className="w-8 h-8 rounded-full bg-white/80 border border-stone-200 flex items-center justify-center shrink-0 text-emerald-700">
                    <Sparkles className="w-4 h-4" />
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-stone-200/60 flex items-center justify-between text-xs sm:text-sm font-semibold text-emerald-800">
                  <span>کہانی شروع کریں</span>
                  <span>←</span>
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Custom Story Input Box */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-200/90 shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-100/50 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center gap-2 mb-3">
          <Wand2 className="w-5 h-5 text-amber-600" />
          <h3 className="text-xl sm:text-2xl font-bold text-stone-900 font-nastaliq">
            {CUSTOM_STORY_QUESTION}
          </h3>
        </div>

        <p className="text-stone-600 text-sm sm:text-base mb-4 font-nastaliq">
          آپ کوئی بھی نیا خیال، جانور، کردار یا مہم لکھ سکتے ہیں (مثلاً: چاند پر کھلنے والا گلاب، ایک عقلمند طوطا):
        </p>

        <form onSubmit={handleCustomSubmit} className="space-y-4">
          <div className="relative">
            <textarea
              id="custom-story-input"
              rows={2}
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder="یہاں لکھیں: مثلاً ایک غریب لڑکا اور سونے کا انڈا دینے والی چڑیا..."
              disabled={isLoading}
              className="w-full px-4 py-3 rounded-2xl border-2 border-stone-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-200 outline-none text-base sm:text-lg font-nastaliq transition resize-none bg-stone-50/50"
            />
          </div>

          {/* Quick Idea Chips */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-stone-500">
              تیز خیالات (آئیڈیاز):
            </span>
            <div className="flex flex-wrap gap-2">
              {QUICK_IDEAS.map((idea, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSelectQuickIdea(idea)}
                  className="px-3 py-1 bg-stone-100 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-300 border border-stone-200 rounded-full text-xs sm:text-sm font-nastaliq transition"
                >
                  {idea}
                </button>
              ))}
            </div>
          </div>

          {/* Start Magic Button */}
          <div className="pt-2 flex justify-end">
            <button
              id="start-magic-button"
              type="submit"
              disabled={!customInput.trim() || isLoading}
              className={`w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-3.5 rounded-2xl font-bold text-lg shadow-md transition ${
                customInput.trim() && !isLoading
                  ? 'bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 hover:from-emerald-800 hover:to-emerald-900 text-white cursor-pointer active:scale-95'
                  : 'bg-stone-200 text-stone-400 cursor-not-allowed'
              }`}
            >
              <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
              <span className="font-nastaliq">{START_MAGIC_BUTTON}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
