import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Volume2,
  VolumeX,
  Play,
  Pause,
  ChevronRight,
  ChevronLeft,
  ArrowRight,
  Copy,
  Check,
  Bookmark,
  BookmarkCheck,
  RotateCcw,
  Sparkles,
  BookOpen,
  Loader2,
} from 'lucide-react';
import { StoryContent } from '../types.ts';

interface StoryPlayerProps {
  story: StoryContent;
  onStop: () => void;
  onSaveToggle?: (story: StoryContent) => void;
  isSaved?: boolean;
}

export const StoryPlayer: React.FC<StoryPlayerProps> = ({
  story,
  onStop,
  onSaveToggle,
  isSaved = false,
}) => {
  const [page, setPage] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'huge'>('large');

  // Audio cache: pageIndex -> base64 audio URL
  const audioCacheRef = useRef<Map<number, string>>(new Map());
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const activeRequestIdRef = useRef<number>(0);
  const isMutedRef = useRef(false);
  const isServerTtsOfflineRef = useRef(false);

  const totalPages = story.pages.length || 15;
  const currentPage = story.pages[page] || story.pages[0];
  const isFirstPage = page === 0;
  const isLastPage = page === totalPages - 1;

  // Sync mute state ref
  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  // Completely stop any playing audio or speech synthesis
  const stopAudio = useCallback(() => {
    activeRequestIdRef.current++;
    if (audioElementRef.current) {
      audioElementRef.current.pause();
      audioElementRef.current.currentTime = 0;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(false);
    setIsLoadingAudio(false);
  }, []);

  // Get narration text for a page (on the last page, include the moral lesson)
  const getPageTextToRead = useCallback(
    (pageIndex: number): string => {
      const targetPage = story.pages[pageIndex];
      if (!targetPage) return '';

      const isLast = pageIndex === story.pages.length - 1;
      if (isLast && story.moralUrdu) {
        return `${targetPage.content}۔ داستان کا اخلاقی سبق: ${story.moralUrdu}`;
      }
      return targetPage.content;
    },
    [story.pages, story.moralUrdu]
  );

  // Pre-fetch next page audio in background
  const prefetchAudio = useCallback(async (pageIndex: number) => {
    if (pageIndex < 0 || pageIndex >= story.pages.length) return;
    if (audioCacheRef.current.has(pageIndex)) return;
    if (isServerTtsOfflineRef.current) return;

    const textToRead = getPageTextToRead(pageIndex);
    if (!textToRead) return;

    try {
      const res = await fetch('/api/generate-speech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToRead }),
      });
      const data = await res.json();
      if (data.fallbackToElderSpeech) {
        isServerTtsOfflineRef.current = true;
        setTimeout(() => {
          isServerTtsOfflineRef.current = false;
        }, 45000);
      } else if (data.audioUrl) {
        audioCacheRef.current.set(pageIndex, data.audioUrl);
      }
    } catch {
      // Background prefetch silent
    }
  }, [story.pages.length, getPageTextToRead]);

  // Deep grandfatherly voice speech synthesis
  // Pitch is set to 0.55 (deep mature baritone) so it sounds like an elder grandfather and NEVER a child or girl
  const playElderlyBrowserSpeech = useCallback(
    (text: string, currentRequestId: number) => {
      if (!('speechSynthesis' in window) || isMutedRef.current) {
        setIsPlaying(false);
        setIsLoadingAudio(false);
        return;
      }

      // Ensure audio element is completely silent
      if (audioElementRef.current) {
        audioElementRef.current.pause();
        audioElementRef.current.currentTime = 0;
      }
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      const voices = window.speechSynthesis.getVoices();

      // Find best available male voice, strictly excluding any female or thin voice
      const maleVoice =
        voices.find(
          (v) =>
            !/female|woman|girl|zira|asma|heera|kalpana|swara|veena/i.test(v.name) &&
            (v.lang.startsWith('ur') || v.lang.startsWith('hi')) &&
            /male|david|rishi|valluvar|dada|elder|man/i.test(v.name)
        ) ||
        voices.find(
          (v) =>
            !/female|woman|girl|zira|asma|heera|kalpana|swara|veena/i.test(v.name) &&
            (v.lang.startsWith('ur') || v.lang.startsWith('hi'))
        ) ||
        voices.find(
          (v) =>
            !/female|woman|girl|zira|asma|heera|kalpana|swara|veena/i.test(v.name) &&
            /male|david|george|james|rishi|daniel/i.test(v.name)
        );

      if (maleVoice) {
        utterance.voice = maleVoice;
      }

      // Deep elder grandfather voice settings:
      utterance.pitch = 0.4; // Very deep, rich grandfather tone (never thin / bareek)
      utterance.rate = 0.8; // Gentle, wise storytelling pace

      utterance.onstart = () => {
        if (currentRequestId === activeRequestIdRef.current) {
          setIsPlaying(true);
          setIsLoadingAudio(false);
        }
      };

      utterance.onend = () => {
        if (currentRequestId === activeRequestIdRef.current) {
          setPage((prev) => {
            if (prev < totalPages - 1) {
              return prev + 1;
            }
            setIsPlaying(false);
            return prev;
          });
        }
      };

      utterance.onerror = () => {
        if (currentRequestId === activeRequestIdRef.current) {
          setIsPlaying(false);
          setIsLoadingAudio(false);
        }
      };

      window.speechSynthesis.speak(utterance);
    },
    [totalPages]
  );

  // Play audio for target page
  const playPageAudio = useCallback(
    async (targetPageIndex: number) => {
      const currentRequestId = ++activeRequestIdRef.current;

      // 1. Immediately kill any current audio & speech so there is NEVER two overlapping voices
      if (audioElementRef.current) {
        audioElementRef.current.pause();
        audioElementRef.current.currentTime = 0;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }

      if (isMutedRef.current) {
        setIsPlaying(false);
        setIsLoadingAudio(false);
        return;
      }

      const textToRead = getPageTextToRead(targetPageIndex);
      if (!textToRead) return;

      // 2. Check cached Gemini Charon audio
      if (audioCacheRef.current.has(targetPageIndex)) {
        const cachedUrl = audioCacheRef.current.get(targetPageIndex)!;
        if (currentRequestId !== activeRequestIdRef.current) return;

        if (audioElementRef.current) {
          audioElementRef.current.src = cachedUrl;
          audioElementRef.current
            .play()
            .then(() => {
              if (currentRequestId === activeRequestIdRef.current) {
                setIsPlaying(true);
                setIsLoadingAudio(false);
              }
            })
            .catch(() => {
              // If browser blocked audio element play, fallback to grandfather browser voice
              if (currentRequestId === activeRequestIdRef.current) {
                playElderlyBrowserSpeech(textToRead, currentRequestId);
              }
            });
          return;
        }
      }

      // 3. If server TTS is currently cooling down from quota limits, start grandfather voice immediately
      if (isServerTtsOfflineRef.current) {
        playElderlyBrowserSpeech(textToRead, currentRequestId);
        return;
      }

      // 4. Fetch from API
      setIsLoadingAudio(true);
      try {
        const res = await fetch('/api/generate-speech', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: textToRead }),
        });

        const data = await res.json();
        if (currentRequestId !== activeRequestIdRef.current) return;

        if (data.fallbackToElderSpeech) {
          isServerTtsOfflineRef.current = true;
          setTimeout(() => {
            isServerTtsOfflineRef.current = false;
          }, 45000);
          playElderlyBrowserSpeech(textToRead, currentRequestId);
        } else if (data.audioUrl && audioElementRef.current && !isMutedRef.current) {
          audioCacheRef.current.set(targetPageIndex, data.audioUrl);
          audioElementRef.current.src = data.audioUrl;
          await audioElementRef.current.play();
          if (currentRequestId === activeRequestIdRef.current) {
            setIsPlaying(true);
            setIsLoadingAudio(false);
          }
        } else {
          // If audioUrl is missing, immediately play grandfather speech
          playElderlyBrowserSpeech(textToRead, currentRequestId);
        }
      } catch {
        if (currentRequestId === activeRequestIdRef.current) {
          playElderlyBrowserSpeech(textToRead, currentRequestId);
        }
      }
    },
    [playElderlyBrowserSpeech, getPageTextToRead]
  );

  // Setup single HTMLAudioElement
  useEffect(() => {
    const audio = new Audio();
    audioElementRef.current = audio;

    const handleEnded = () => {
      // Automatically advance to next page and continue auto-playing!
      setPage((prev) => {
        if (prev < totalPages - 1) {
          return prev + 1;
        }
        setIsPlaying(false);
        return prev;
      });
    };

    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('ended', handleEnded);
      audio.pause();
      audio.src = '';
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [totalPages]);

  // When page state changes, trigger audio for that page
  useEffect(() => {
    if (!isMuted) {
      playPageAudio(page);
    }
    // Pre-cache next page
    if (page + 1 < totalPages) {
      prefetchAudio(page + 1);
    }
  }, [page, isMuted, totalPages, playPageAudio, prefetchAudio]);

  // Turn page or jump directly to selected page number:
  // When user selects ANY page number (even the current one), audio immediately starts from that page!
  const changePage = (newPage: number) => {
    const clamped = Math.max(0, Math.min(totalPages - 1, newPage));
    stopAudio();
    setIsMuted(false);
    if (clamped !== page) {
      setPage(clamped);
      // useEffect on `page` will trigger playPageAudio(clamped)
    } else {
      // If clicking the currently selected page, force replay from start of that page
      playPageAudio(clamped);
    }
  };

  const toggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      playPageAudio(page);
    } else {
      setIsMuted(true);
      stopAudio();
    }
  };

  const togglePlayPause = () => {
    if (isPlaying || isLoadingAudio) {
      stopAudio();
    } else {
      setIsMuted(false);
      playPageAudio(page);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        if (page < totalPages - 1) changePage(page + 1);
      } else if (e.key === 'ArrowRight') {
        if (page > 0) changePage(page - 1);
      } else if (e.key === ' ') {
        e.preventDefault();
        togglePlayPause();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [page, totalPages, isPlaying, isLoadingAudio]);

  const handleCopy = () => {
    const fullStoryText =
      `${story.title}\n\n` +
      story.pages.map((p, idx) => `[صفحہ ${idx + 1}]\n${p.content}`).join('\n\n') +
      (story.moralUrdu ? `\n\nکہانی کا اخلاقی سبق: ${story.moralUrdu}` : '');

    navigator.clipboard.writeText(fullStoryText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  const fontSizeClass = {
    normal: 'text-xl sm:text-2xl leading-loose',
    large: 'text-2xl sm:text-3xl leading-loose',
    huge: 'text-3xl sm:text-4xl leading-loose',
  }[fontSize];

  return (
    <div id="story-player-container" className="w-full max-w-3xl mx-auto space-y-4">
      {/* Top action bar */}
      <div className="flex items-center justify-between gap-2 bg-white/90 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-stone-200 shadow-sm">
        <button
          id="back-home-button"
          onClick={() => {
            stopAudio();
            onStop();
          }}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-stone-700 hover:text-emerald-800 hover:bg-emerald-50 rounded-xl transition text-sm sm:text-base font-medium cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>مرکزی صفحہ</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Font Size Selector */}
          <div className="flex items-center bg-stone-100 rounded-xl p-0.5 text-xs sm:text-sm">
            <button
              onClick={() => setFontSize('normal')}
              className={`px-2 py-1 rounded-lg transition ${
                fontSize === 'normal' ? 'bg-white shadow-xs font-bold text-emerald-800' : 'text-stone-600'
              }`}
            >
              چھوٹا
            </button>
            <button
              onClick={() => setFontSize('large')}
              className={`px-2 py-1 rounded-lg transition ${
                fontSize === 'large' ? 'bg-white shadow-xs font-bold text-emerald-800' : 'text-stone-600'
              }`}
            >
              درمیانہ
            </button>
            <button
              onClick={() => setFontSize('huge')}
              className={`px-2 py-1 rounded-lg transition ${
                fontSize === 'huge' ? 'bg-white shadow-xs font-bold text-emerald-800' : 'text-stone-600'
              }`}
            >
              بڑا
            </button>
          </div>

          {/* Bookmark Button */}
          {onSaveToggle && (
            <button
              id="save-story-button"
              onClick={() => onSaveToggle(story)}
              className={`p-2 rounded-xl border transition cursor-pointer ${
                isSaved
                  ? 'bg-amber-100 border-amber-300 text-amber-800'
                  : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
              }`}
              title={isSaved ? 'محفوظ کی گئی ہے' : 'کہانی محفوظ کریں'}
            >
              {isSaved ? <BookmarkCheck className="w-4 h-4 fill-amber-600" /> : <Bookmark className="w-4 h-4" />}
            </button>
          )}

          {/* Copy story button */}
          <button
            id="copy-story-button"
            onClick={handleCopy}
            className="p-2 rounded-xl border border-stone-200 bg-stone-50 text-stone-600 hover:bg-stone-100 transition cursor-pointer"
            title="کہانی کاپی کریں"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Story Book Card */}
      <div className="relative bg-white rounded-3xl shadow-xl border border-amber-200/80 overflow-hidden">
        {/* Subtle decorative top strip */}
        <div className="h-2.5 bg-gradient-to-r from-emerald-600 via-amber-500 to-emerald-700" />

        <div className="p-6 sm:p-10">
          {/* Main Story Title */}
          <div className="text-center mb-6 pb-4 border-b border-amber-100">
            <h1
              id="story-main-title"
              className="text-2xl sm:text-4xl font-bold text-emerald-950 font-nastaliq tracking-tight"
            >
              {story.title}
            </h1>
          </div>

          {/* Continuous Flowing Story Page Content */}
          <AnimatePresence mode="wait">
            <motion.div
              key={page}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className={`p-6 sm:p-9 rounded-2xl border min-h-[240px] sm:min-h-[280px] flex flex-col justify-between transition-colors ${
                isPlaying
                  ? 'bg-amber-50/60 border-amber-300/80 shadow-inner'
                  : 'bg-stone-50/60 border-stone-200/80'
              }`}
            >
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <span className="text-3xl sm:text-4xl select-none mt-1" role="img" aria-hidden="true">
                    {currentPage.emoji || '✨'}
                  </span>
                  <p className={`text-stone-900 font-nastaliq ${fontSizeClass} flex-1`}>
                    {currentPage.content}
                  </p>
                </div>
              </div>

              {/* Moral on the 15th (last) page */}
              {isLastPage && story.moralUrdu && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.97 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.15 }}
                  className="mt-6 p-5 rounded-2xl bg-emerald-100/90 border-2 border-emerald-400 text-emerald-950 shadow-xs"
                >
                  <div className="flex items-center gap-2 font-bold text-base sm:text-lg text-emerald-950 mb-1 font-nastaliq">
                    <Sparkles className="w-5 h-5 text-amber-600" />
                    <span>داستان کا اخلاقی سبق:</span>
                  </div>
                  <p className="text-stone-900 font-nastaliq text-lg sm:text-xl font-medium">
                    {story.moralUrdu}
                  </p>
                </motion.div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Lower Section: Page Numbers, Bottom Voice Narration, and Page Controls */}
          <div className="mt-6 space-y-4 pt-4 border-t border-amber-100">
            {/* Small Compact Page Numbers at Bottom */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 px-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-stone-500 font-nastaliq font-medium">
                  صفحہ:
                </span>
                <span className="px-2 py-0.5 rounded-md bg-stone-100 text-emerald-900 font-bold text-xs font-nastaliq border border-stone-200">
                  {page + 1} از {totalPages}
                </span>
              </div>

              {/* 15-page numbers: Clicking ANY number immediately jumps to that page AND starts audio */}
              <div className="flex items-center gap-1 flex-wrap justify-center">
                {Array.from({ length: totalPages }).map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => changePage(idx)}
                    className={`h-6 min-w-[24px] px-1 text-xs font-bold rounded transition cursor-pointer flex items-center justify-center ${
                      idx === page
                        ? 'bg-emerald-700 text-white shadow-xs scale-110'
                        : idx < page
                        ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                        : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                    }`}
                    title={`صفحہ ${idx + 1} پر جائیں اور آواز سنیں`}
                  >
                    {idx + 1}
                  </button>
                ))}
              </div>
            </div>

            {/* Bottom Voice Control Bar */}
            <div
              id="bottom-voice-bar"
              className="flex items-center justify-between gap-3 bg-stone-100/90 hover:bg-stone-100 border border-stone-200/90 rounded-2xl px-4 py-2.5 transition"
            >
              <div className="flex items-center gap-3">
                <button
                  id="bottom-audio-toggle"
                  onClick={togglePlayPause}
                  disabled={isLoadingAudio}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold font-nastaliq shadow-xs transition cursor-pointer ${
                    isPlaying
                      ? 'bg-amber-400 text-stone-950 hover:bg-amber-300'
                      : 'bg-emerald-700 text-white hover:bg-emerald-800'
                  }`}
                  title={isPlaying ? 'آواز روکیں' : 'آواز سنیں'}
                >
                  {isLoadingAudio ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>آواز تیار ہو رہی ہے...</span>
                    </>
                  ) : isPlaying ? (
                    <>
                      <Pause className="w-4 h-4 fill-current" />
                      <span>آواز روکیں (Pause)</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-current" />
                      <span>آواز سنیں</span>
                    </>
                  )}
                </button>

                {/* Status Indicator */}
                <div className="flex items-center gap-1.5 text-xs text-stone-600 font-nastaliq">
                  {isPlaying ? (
                    <>
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                      </span>
                      <span className="text-emerald-800 font-semibold">
                        دادا جان کی آواز جاری ہے...
                      </span>
                    </>
                  ) : (
                    <span>کسی بھی صفحے کے نمبر پر کلک کریں، آواز وہیں سے شروع ہوگی</span>
                  )}
                </div>
              </div>

              {/* Mute / Unmute Toggle */}
              <button
                onClick={toggleMute}
                className={`p-2 rounded-xl border text-xs transition cursor-pointer ${
                  isMuted
                    ? 'bg-rose-50 border-rose-200 text-rose-700'
                    : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
                title={isMuted ? 'آواز کھولیں' : 'آواز بند کریں'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>

            {/* Page Navigation Controls */}
            <div className="flex items-center justify-between gap-3 pt-2">
              <button
                id="prev-page-button"
                onClick={() => changePage(page - 1)}
                disabled={isFirstPage}
                className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold font-nastaliq transition cursor-pointer text-sm sm:text-base ${
                  isFirstPage
                    ? 'opacity-40 cursor-not-allowed bg-stone-100 text-stone-400'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-800 active:scale-95'
                }`}
              >
                <ChevronRight className="w-4 h-4" />
                <span>پچھلا صفحہ</span>
              </button>

              {isLastPage ? (
                <button
                  id="restart-story-button"
                  onClick={() => changePage(0)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 transition text-xs sm:text-sm font-nastaliq font-bold cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-700" />
                  <span>دوبارہ سنیں</span>
                </button>
              ) : null}

              {isLastPage ? (
                <button
                  id="finish-story-button"
                  onClick={() => {
                    stopAudio();
                    onStop();
                  }}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold font-nastaliq shadow-md transition cursor-pointer active:scale-95 text-sm sm:text-base"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>نئی کہانی</span>
                </button>
              ) : (
                <button
                  id="next-page-button"
                  onClick={() => changePage(page + 1)}
                  className="inline-flex items-center gap-1.5 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold font-nastaliq shadow-md transition cursor-pointer active:scale-95 text-sm sm:text-base"
                >
                  <span>اگلا صفحہ</span>
                  <ChevronLeft className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
