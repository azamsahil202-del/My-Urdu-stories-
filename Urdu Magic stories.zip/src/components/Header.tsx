import React from 'react';
import { Sparkles, BookMarked, BookOpen } from 'lucide-react';
import { APP_TITLE_URDU } from '../types.ts';

interface HeaderProps {
  onOpenSavedStories: () => void;
  savedStoriesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSavedStories,
  savedStoriesCount,
}) => {
  return (
    <header className="w-full border-b border-amber-200/70 bg-white/90 backdrop-blur-md sticky top-0 z-30 shadow-xs">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
        {/* Brand / Logo */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-700 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-700/20">
            <Sparkles className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-emerald-950 font-nastaliq tracking-tight">
              {APP_TITLE_URDU}
            </h1>
            <p className="text-xs text-stone-500 font-nastaliq hidden sm:block">
              بچوں کے لیے جادوئی، دلچسپ اور سبق آموز اردو کہانیاں
            </p>
          </div>
        </div>

        {/* Saved Stories Action */}
        <div className="flex items-center gap-2">
          <button
            id="open-saved-stories-button"
            onClick={onOpenSavedStories}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-50 hover:bg-amber-100/90 text-amber-900 border border-amber-200 text-sm font-medium transition cursor-pointer shadow-2xs"
            title="محفوظ کردہ کہانیاں دیکھیں"
          >
            <BookMarked className="w-4 h-4 text-amber-700" />
            <span className="font-nastaliq text-sm sm:text-base">محفوظ کہانیاں</span>
            {savedStoriesCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-emerald-700 text-white text-xs flex items-center justify-center font-bold">
                {savedStoriesCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
