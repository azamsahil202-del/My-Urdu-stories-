import React from 'react';
import { X, Trash2, BookOpen, Calendar, Sparkles } from 'lucide-react';
import { StoryContent } from '../types.ts';

interface SavedStoriesModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedStories: StoryContent[];
  onSelectStory: (story: StoryContent) => void;
  onDeleteStory: (storyId: string) => void;
  onClearAll: () => void;
}

export const SavedStoriesModal: React.FC<SavedStoriesModalProps> = ({
  isOpen,
  onClose,
  savedStories,
  onSelectStory,
  onDeleteStory,
  onClearAll,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/50 backdrop-blur-xs">
      <div
        id="saved-stories-modal"
        className="bg-white rounded-3xl max-w-xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-amber-200 overflow-hidden"
      >
        {/* Modal Header */}
        <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-amber-50/60">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-600" />
            <h3 className="text-xl font-bold text-stone-900 font-nastaliq">
              محفوظ شدہ کہانیاں ({savedStories.length})
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-stone-200 text-stone-600 transition"
            title="بند کریں"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1">
          {savedStories.length === 0 ? (
            <div className="text-center py-12 text-stone-500 space-y-2">
              <BookOpen className="w-12 h-12 mx-auto text-stone-300" />
              <p className="font-nastaliq text-lg">ابھی تک کوئی کہانی محفوظ نہیں کی گئی۔</p>
              <p className="text-xs text-stone-400">
                کہانی پڑھتے وقت اوپر بک مارک بٹن دبا کر کہانی محفوظ کر سکتے ہیں۔
              </p>
            </div>
          ) : (
            savedStories.map((story) => (
              <div
                key={story.id || story.title}
                className="p-4 rounded-2xl border border-stone-200 hover:border-emerald-400 bg-stone-50/60 hover:bg-emerald-50/40 transition flex items-center justify-between gap-3"
              >
                <div
                  onClick={() => {
                    onSelectStory(story);
                    onClose();
                  }}
                  className="flex-1 cursor-pointer"
                >
                  <h4 className="font-bold text-emerald-950 font-nastaliq text-lg">
                    {story.title}
                  </h4>
                  <p className="text-xs text-stone-500 font-nastaliq line-clamp-1 mt-0.5">
                    {story.pages[0]?.content || ""}
                  </p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-stone-400">
                    <span>{story.pages.length} صفحات</span>
                    {story.createdAt && (
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(story.createdAt).toLocaleDateString('ur-PK')}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      onSelectStory(story);
                      onClose();
                    }}
                    className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold font-nastaliq transition"
                  >
                    پڑھیں
                  </button>
                  <button
                    onClick={() => story.id && onDeleteStory(story.id)}
                    className="p-1.5 text-stone-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition"
                    title="حذف کریں"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer */}
        {savedStories.length > 0 && (
          <div className="p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-between">
            <button
              onClick={onClearAll}
              className="text-xs text-red-600 hover:text-red-700 font-medium font-nastaliq"
            >
              تمام کہانیاں حذف کریں
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl text-sm font-medium transition"
            >
              بند کریں
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
