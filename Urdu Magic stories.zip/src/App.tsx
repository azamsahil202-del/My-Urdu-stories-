import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.tsx';
import { ThemeSelector } from './components/ThemeSelector.tsx';
import { StoryPlayer } from './components/StoryPlayer.tsx';
import { LoadingScreen } from './components/LoadingScreen.tsx';
import { SavedStoriesModal } from './components/SavedStoriesModal.tsx';
import {
  AppState,
  StoryContent,
  StoryTheme,
  THEMES,
  APP_TITLE_URDU,
} from './types.ts';
import { AlertCircle, Sparkles } from 'lucide-react';

const SAVED_STORIES_STORAGE_KEY = 'urdu_magical_stories_v1';

export default function App() {
  const [appState, setAppState] = useState<AppState>(AppState.HOME);
  const [currentStory, setCurrentStory] = useState<StoryContent | null>(null);
  const [loadingTopic, setLoadingTopic] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedStories, setSavedStories] = useState<StoryContent[]>([]);
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);

  // Load saved stories from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(SAVED_STORIES_STORAGE_KEY);
      if (stored) {
        setSavedStories(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Failed to load saved stories from localStorage', e);
    }
  }, []);

  // Save stories to localStorage whenever savedStories changes
  const saveToStorage = (stories: StoryContent[]) => {
    setSavedStories(stories);
    try {
      localStorage.setItem(SAVED_STORIES_STORAGE_KEY, JSON.stringify(stories));
    } catch (e) {
      console.error('Failed to save to localStorage', e);
    }
  };

  const handleStartThemeStory = async (theme: StoryTheme) => {
    setLoadingTopic(theme.titleUrdu);
    setAppState(AppState.LOADING);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/generate-story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          themePrompt: theme.prompt,
          themeId: theme.id,
        }),
      });

      if (!response.ok) {
        throw new Error(`سرور کی طرف سے خرابی (${response.status})`);
      }

      const data = await response.json();
      if (data.story) {
        const enrichedStory: StoryContent = {
          ...data.story,
          id: `story_${Date.now()}`,
          themeId: theme.id,
          createdAt: Date.now(),
        };
        setCurrentStory(enrichedStory);
        setAppState(AppState.STORY_PLAYER);
      } else {
        throw new Error('کہانی موصول نہیں ہو سکی');
      }
    } catch (err: any) {
      console.error('Story generation error:', err);
      setErrorMessage(
        'کہانی بناتے وقت عارضی مسئلہ پیش آیا۔ براہ کرم دوبارہ کوشش کریں۔'
      );
      setAppState(AppState.HOME);
    }
  };

  const handleStartCustomStory = async (customPrompt: string) => {
    setLoadingTopic(customPrompt);
    setAppState(AppState.LOADING);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/generate-story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customTopic: customPrompt,
        }),
      });

      if (!response.ok) {
        throw new Error(`سرور کی طرف سے خرابی (${response.status})`);
      }

      const data = await response.json();
      if (data.story) {
        const enrichedStory: StoryContent = {
          ...data.story,
          id: `story_${Date.now()}`,
          customTopic: customPrompt,
          createdAt: Date.now(),
        };
        setCurrentStory(enrichedStory);
        setAppState(AppState.STORY_PLAYER);
      } else {
        throw new Error('کہانی موصول نہیں ہو سکی');
      }
    } catch (err: any) {
      console.error('Custom story error:', err);
      setErrorMessage(
        'کہانی بناتے وقت عارضی مسئلہ پیش آیا۔ براہ کرم دوبارہ کوشش کریں۔'
      );
      setAppState(AppState.HOME);
    }
  };

  const handleStop = () => {
    setAppState(AppState.HOME);
  };

  const handleSaveToggle = (storyToToggle: StoryContent) => {
    const isAlreadySaved = savedStories.some(
      (s) => s.id === storyToToggle.id || s.title === storyToToggle.title
    );

    if (isAlreadySaved) {
      const filtered = savedStories.filter(
        (s) => s.id !== storyToToggle.id && s.title !== storyToToggle.title
      );
      saveToStorage(filtered);
    } else {
      const updated = [storyToToggle, ...savedStories];
      saveToStorage(updated);
    }
  };

  const handleDeleteSavedStory = (storyId: string) => {
    const filtered = savedStories.filter((s) => s.id !== storyId);
    saveToStorage(filtered);
  };

  const handleClearAllSaved = () => {
    if (confirm('کیا آپ تمام محفوظ کہانیاں حذف کرنا چاہتے ہیں؟')) {
      saveToStorage([]);
    }
  };

  const handleSelectSavedStory = (story: StoryContent) => {
    setCurrentStory(story);
    setAppState(AppState.STORY_PLAYER);
  };

  const isCurrentStorySaved = Boolean(
    currentStory &&
      savedStories.some(
        (s) => s.id === currentStory.id || s.title === currentStory.title
      )
  );

  return (
    <div className="min-h-screen flex flex-col font-arabic bg-amber-50/40 text-stone-800">
      {/* Top Header */}
      <Header
        onOpenSavedStories={() => setIsSavedModalOpen(true)}
        savedStoriesCount={savedStories.length}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-10 flex flex-col items-center">
        {/* Error notification */}
        {errorMessage && (
          <div className="w-full max-w-2xl mb-6 p-4 rounded-2xl bg-red-50 border border-red-200 text-red-800 flex items-center justify-between gap-3 text-sm font-nastaliq">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-xs font-bold text-red-700 hover:text-red-900"
            >
              ٹھیک ہے
            </button>
          </div>
        )}

        {/* Home Screen (Theme & Topic Selection) */}
        {appState === AppState.HOME && (
          <ThemeSelector
            onStartThemeStory={handleStartThemeStory}
            onStartCustomStory={handleStartCustomStory}
            isLoading={false}
          />
        )}

        {/* Loading Screen */}
        {appState === AppState.LOADING && (
          <LoadingScreen topicTitle={loadingTopic} />
        )}

        {/* Story Player Screen */}
        {appState === AppState.STORY_PLAYER && currentStory && (
          <StoryPlayer
            story={currentStory}
            onStop={handleStop}
            onSaveToggle={handleSaveToggle}
            isSaved={isCurrentStorySaved}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-amber-200/60 py-6 text-center text-xs text-stone-500 bg-white/60">
        <p className="font-nastaliq">
          {APP_TITLE_URDU} — اردو زبان کے بچوں کے لیے تخیل، سحر اور اخلاقی تربیت کی کہانیوں کا جادوئی جہان
        </p>
      </footer>

      {/* Saved Stories Modal */}
      <SavedStoriesModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedStories={savedStories}
        onSelectStory={handleSelectSavedStory}
        onDeleteStory={handleDeleteSavedStory}
        onClearAll={handleClearAllSaved}
      />
    </div>
  );
}
