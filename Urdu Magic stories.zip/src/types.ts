export interface StoryPage {
  pageNumber?: number;
  title: string;
  content: string;
  emoji?: string;
}

export interface StoryContent {
  id?: string;
  title: string;
  moralUrdu?: string;
  pages: StoryPage[];
  themeId?: string;
  customTopic?: string;
  createdAt?: number;
}

export enum AppState {
  HOME = 'HOME',
  LOADING = 'LOADING',
  STORY_PLAYER = 'STORY_PLAYER',
}

export interface StoryTheme {
  id: string;
  titleUrdu: string;
  icon: string;
  prompt: string;
  desc?: string;
  accentBg?: string;
  accentBorder?: string;
  accentText?: string;
}

export const APP_TITLE_URDU = "اردو جادو کہانیاں";
export const CUSTOM_STORY_QUESTION = "آج کون سی جادوئی کہانی سننی ہے؟";
export const START_MAGIC_BUTTON = "جادو شروع کرو ✨";

export const THEMES: StoryTheme[] = [
  {
    id: 'jungle',
    titleUrdu: 'جنگل کی کہانی',
    icon: '🌳',
    prompt: 'Ek jungle ki jadui kahani Urdu mein',
    desc: 'بولنے والے درخت، دوست پرندے اور سرسبز جنگل کے راز',
    accentBg: 'bg-emerald-50 hover:bg-emerald-100/80',
    accentBorder: 'border-emerald-200 hover:border-emerald-400',
    accentText: 'text-emerald-800',
  },
  {
    id: 'pariyan',
    titleUrdu: 'پریوں کا دیس',
    icon: '🧚',
    prompt: 'Ek pariyon ke des ki jadui kahani Urdu mein',
    desc: 'چاندی کے پر، نورانی محل اور اچھے بچوں کے سپنے',
    accentBg: 'bg-purple-50 hover:bg-purple-100/80',
    accentBorder: 'border-purple-200 hover:border-purple-400',
    accentText: 'text-purple-800',
  },
  {
    id: 'samandar',
    titleUrdu: 'سمندر کا راز',
    icon: '🌊',
    prompt: 'Ek samandar ke raaz ki jadui kahani Urdu mein',
    desc: 'گہرے نیلے سمندر، جگمگاتی سنہری مچھلیاں اور جادوئی موتی',
    accentBg: 'bg-cyan-50 hover:bg-cyan-100/80',
    accentBorder: 'border-cyan-200 hover:border-cyan-400',
    accentText: 'text-cyan-800',
  },
  {
    id: 'khala',
    titleUrdu: 'خلا کا سفر',
    icon: '🚀',
    prompt: 'Ek khala ke safar ki jadui kahani Urdu mein',
    desc: 'تیز رفتار راکٹ، چاند کا خرگوش اور کہکشاؤں کے چراغ',
    accentBg: 'bg-indigo-50 hover:bg-indigo-100/80',
    accentBorder: 'border-indigo-200 hover:border-indigo-400',
    accentText: 'text-indigo-800',
  },
];
