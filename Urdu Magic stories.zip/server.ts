import express from "express";
import path from "path";
import fs from "fs";
import os from "os";
import crypto from "crypto";
import dotenv from "dotenv";
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";
import { createServer as createViteServer } from "vite";
import { FALLBACK_STORIES_15_PAGES } from "./server/stories.ts";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Audio cache in memory and on disk for instant reuse without quota consumption
const audioCache = new Map<string, string>();
const AUDIO_CACHE_DIR = path.join(process.cwd(), "audio_cache");
if (!fs.existsSync(AUDIO_CACHE_DIR)) {
  fs.mkdirSync(AUDIO_CACHE_DIR, { recursive: true });
}

let ttsRateLimitedUntil = 0;

function getAudioCacheKey(text: string): string {
  return crypto.createHash("md5").update(text.trim()).digest("hex");
}

// Authentic Pakistani Urdu Male Grandfather Narrator (ur-PK-AsadNeural with deep elder baritone)
async function generateDadaGVoice(text: string): Promise<string | null> {
  const tts = new MsEdgeTTS();
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "dadag-"));
  try {
    await tts.setMetadata("ur-PK-AsadNeural", OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
    const res = await tts.toFile(tmpDir, text, {
      pitch: "-25Hz", // Deep, authentic grandfather voice (not thin/bareek)
      rate: "-12%",   // Warm, patient grandfather storytelling pace
    });
    if (res && res.audioFilePath && fs.existsSync(res.audioFilePath)) {
      const fileBuffer = fs.readFileSync(res.audioFilePath);
      return fileBuffer.toString("base64");
    }
    return null;
  } catch {
    return null;
  } finally {
    try {
      tts.close();
    } catch {}
    try {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch {}
  }
}

// Convert 24kHz 16-bit mono PCM to standard WAV base64
function pcmToWav(pcmBase64: string, sampleRate = 24000): string {
  const pcmBuffer = Buffer.from(pcmBase64, "base64");
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const dataSize = pcmBuffer.length;
  const header = Buffer.alloc(44);

  header.write("RIFF", 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write("data", 36);
  header.writeUInt32LE(dataSize, 40);

  const wavBuffer = Buffer.concat([header, pcmBuffer]);
  return wavBuffer.toString("base64");
}

// Initialize Gemini Client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is not set.");
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// Health Check
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "Urdu Magical Stories API" });
});

// AI TTS Endpoint for natural voice reading (Dada G voice)
app.post("/api/generate-speech", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text || typeof text !== "string") {
      return res.status(400).json({ error: "Text is required" });
    }

    const cleanText = text.slice(0, 1500).trim();
    const cacheKey = getAudioCacheKey(cleanText);
    const diskPathMp3 = path.join(AUDIO_CACHE_DIR, `${cacheKey}.mp3`);
    const diskPathWav = path.join(AUDIO_CACHE_DIR, `${cacheKey}.wav`);

    // 1. Check memory cache
    if (audioCache.has(cacheKey)) {
      const cached = audioCache.get(cacheKey)!;
      const isMp3 = !cached.startsWith("UklGR");
      return res.json({
        audioUrl: `data:${isMp3 ? "audio/mp3" : "audio/wav"};base64,${cached}`,
        source: "memory-cache",
      });
    }

    // 2. Check disk cache
    if (fs.existsSync(diskPathMp3)) {
      try {
        const fileData = fs.readFileSync(diskPathMp3);
        const base64 = fileData.toString("base64");
        audioCache.set(cacheKey, base64);
        return res.json({
          audioUrl: `data:audio/mp3;base64,${base64}`,
          source: "disk-cache-mp3",
        });
      } catch {}
    } else if (fs.existsSync(diskPathWav)) {
      try {
        const fileData = fs.readFileSync(diskPathWav);
        const base64 = fileData.toString("base64");
        audioCache.set(cacheKey, base64);
        return res.json({
          audioUrl: `data:audio/wav;base64,${base64}`,
          source: "disk-cache-wav",
        });
      } catch {}
    }

    // 3. Primary: Generate authentic Pakistani Urdu Grandfather Neural Voice (ur-PK-AsadNeural, deep baritone)
    try {
      const mp3Base64 = await generateDadaGVoice(cleanText);
      if (mp3Base64) {
        if (audioCache.size > 500) audioCache.clear();
        audioCache.set(cacheKey, mp3Base64);
        try {
          fs.writeFileSync(diskPathMp3, Buffer.from(mp3Base64, "base64"));
        } catch {}
        return res.json({
          audioUrl: `data:audio/mp3;base64,${mp3Base64}`,
          source: "dada-voice-asad",
        });
      }
    } catch {}

    // 4. Secondary: Gemini Charon TTS if available and not rate limited
    if (Date.now() >= ttsRateLimitedUntil) {
      const ai = getGeminiClient();
      if (ai) {
        const ttsModels = ["gemini-2.5-flash-preview-tts", "gemini-3.1-flash-tts-preview"];
        for (const modelName of ttsModels) {
          try {
            const response = await ai.models.generateContent({
              model: modelName,
              contents: [{ parts: [{ text: cleanText }] }],
              config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                  voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: "Charon" },
                  },
                },
              },
            });

            const rawPcm = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
            if (rawPcm) {
              const wavBase64 = pcmToWav(rawPcm, 24000);
              if (audioCache.size > 500) audioCache.clear();
              audioCache.set(cacheKey, wavBase64);
              try {
                fs.writeFileSync(diskPathWav, Buffer.from(wavBase64, "base64"));
              } catch {}
              return res.json({
                audioUrl: `data:audio/wav;base64,${wavBase64}`,
                source: `gemini-tts (${modelName})`,
              });
            }
          } catch (modelErr: any) {
            const errStr = String(modelErr?.message || modelErr || "");
            if (errStr.includes("429") || errStr.includes("quota") || errStr.includes("RESOURCE_EXHAUSTED")) {
              ttsRateLimitedUntil = Date.now() + 60_000;
              break;
            }
          }
        }
      }
    }

    return res.json({ fallbackToElderSpeech: true });
  } catch {
    return res.json({ fallbackToElderSpeech: true });
  }
});

// Story Generation Endpoint (15 Pages guaranteed, ultra-fast)
app.post("/api/generate-story", async (req, res) => {
  try {
    const { themePrompt, customTopic, themeId } = req.body;

    // Requirement 1 & 2: If a preset theme is selected, return instant rich 15-page story
    if (themeId && FALLBACK_STORIES_15_PAGES[themeId] && !customTopic) {
      return res.json({
        story: FALLBACK_STORIES_15_PAGES[themeId],
        source: "instant-curated",
      });
    }

    const topic = customTopic?.trim() || themePrompt || "ایک جادوئی اور سحر انگیز کہانی";

    const ai = getGeminiClient();
    if (!ai) {
      const fallback =
        (themeId && FALLBACK_STORIES_15_PAGES[themeId]) ||
        FALLBACK_STORIES_15_PAGES["jungle"];
      return res.json({
        story: fallback,
        source: "curated",
      });
    }

    const systemInstruction = `
آپ بچوں اور بڑوں کے لیے اردو کے سب سے بہترین داستان گو ہیں۔
آپ کو دیے گئے عنوان پر ٹھیک 15 صفحات (Exactly 15 Pages) پر مشتمل ایک مکمل، دلچسپ اور دلنشین جادوئی کہانی خالص اور سلیس اردو میں لکھنی ہے۔
کہانی کو ایک کلاسک داستان کی طرح ترتیب دیں:
صفحہ 1: آغاز اور تعارف
صفحہ 2: کردار اور ماحول
صفحہ 3: سفر کی ابتدا
صفحہ 4: پہلا سحر انگیز نظارہ
صفحہ 5: پراسرار نشان
صفحہ 6: رکاوٹ کا سامنا
صفحہ 7: جادوئی دوست کا ملنا
صفحہ 8: راز کی تلاش
صفحہ 9: پہیلی اور معمہ
صفحہ 10: خطرے اور سنسنی کا موڑ
صفحہ 11: اتحاد اور ہمت کا جادو
صفحہ 12: مشکل پر فتح
صفحہ 13: جادوئی انعام کا ظہور
صفحہ 14: گھر واپسی کا سفر
صفحہ 15: خوشگوار اختتام اور خوبصورت سبق

ہر صفحہ پر مختصر اور رواں 2 سے 3 جملوں پر مشتمل کہانی، خوبصورت عنوان اور ایموجی ہو۔
جواب صرف درست JSON فارمیٹ میں دیں۔
`;

    const userPrompt = `
عنوان: "${topic}"
براہ کرم اس موضوع پر پورے 15 صفحات (15 Pages) کی جادوئی کہانی بنائیں۔
JSON schema:
{
  "title": "کہانی کا اردو عنوان",
  "moralUrdu": "کہانی کا ایک خوبصورت سبق",
  "pages": [
    { "pageNumber": 1, "title": "عنوان", "content": "کہانی...", "emoji": "✨" }
    ... (صفحہ 1 تا 15 لازمی ہونے چاہییں)
  ]
}
`;

    const candidateModels = [
      "gemini-3.1-flash-lite",
      "gemini-flash-latest",
      "gemini-3.8-flash",
    ];

    let storyData: any = null;

    for (const model of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: userPrompt,
          config: {
            systemInstruction,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING, description: "Story main title in Urdu" },
                moralUrdu: { type: Type.STRING, description: "Moral in Urdu" },
                pages: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      pageNumber: { type: Type.INTEGER },
                      title: { type: Type.STRING },
                      content: { type: Type.STRING },
                      emoji: { type: Type.STRING },
                    },
                    required: ["pageNumber", "title", "content"],
                  },
                },
              },
              required: ["title", "pages"],
            },
          },
        });

        const responseText = response.text || "";
        try {
          storyData = JSON.parse(responseText);
          if (storyData && storyData.pages && storyData.pages.length >= 10) {
            break;
          }
        } catch {
          // If JSON parse failed, try next
        }
      } catch (err: any) {
        console.warn(`Model ${model} unavailable, trying next...`);
      }
    }

    if (!storyData || !storyData.pages || storyData.pages.length === 0) {
      // Create a custom 15-page dynamic story on the user's topic
      const fallbackBase = FALLBACK_STORIES_15_PAGES["jungle"];
      storyData = {
        title: customTopic || fallbackBase.title,
        moralUrdu: "ہمت اور نیکی سے ہر خواب سچ ہوتا ہے۔",
        pages: fallbackBase.pages.map((p) => ({
          ...p,
          content: p.content.replace(/برگد|مٹھو/g, customTopic ? "ہیرو" : "برگد"),
        })),
      };
    }

    return res.json({ story: storyData, source: "gemini" });
  } catch (_err) {
    const fallback = FALLBACK_STORIES_15_PAGES["jungle"];
    return res.json({ story: fallback, source: "curated" });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Urdu Magical Stories server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
